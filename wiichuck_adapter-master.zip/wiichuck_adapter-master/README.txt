Very simple adpater for hooking a Wii Nunchuck to your Arduino 
or other microcontroller.

Example Arduino code is is in firmware/WiichuckDemo.

More details here:
http://todbot.com/blog/2008/02/18/wiichuck-wii-nunchuck-adapter-available/


